# ReadMe file - cpp_imagesub
*Made by ChatterArm team*

# Package run

```
ros2 run cpp_imagesub image_subscriber
```


